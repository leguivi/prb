package com.proyecto

class GeoPoint(
    var latitude : Double,
    var longitude : Double
)